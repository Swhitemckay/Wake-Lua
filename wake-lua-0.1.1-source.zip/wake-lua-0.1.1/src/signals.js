import {channel, projectPages, usedNumberChannels} from './project.js';

const escape = value => String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function isWholeNumberInput(name){return /\b(?:count|ammo|quantity|rounds?|missiles?)\b/i.test(String(name))}
export function createSignalPanel({element,getProject,change}) {
  let showAll=false;
  function render(){
    const p=getProject(),pages=projectPages(p),layers=pages.flatMap(pg=>pg.layers);
    const numbers=showAll?Array.from({length:32},(_,i)=>i+1):usedNumberChannels(p);
    const bools=showAll?Array.from({length:32},(_,i)=>i+1):[...new Set(pages.flatMap(pg=>(pg.links||[]).filter(l=>l.inputChannel).map(l=>l.inputChannel)).concat(p.mode==='code'?[...p.code.matchAll(/input\s*\.\s*getBool\s*\(\s*(\d+)\s*\)/g)].map(m=>channel(m[1])):[]))].sort((a,b)=>a-b);
    const outputChannels=[...new Set(layers.filter(l=>['button','zone'].includes(l.kind)&&!l.hidden).map(l=>channel(l.outputChannel)))].sort((a,b)=>a-b);
    element.innerHTML=`<div class="signal-heading"><div><h3>Live inputs</h3><p>Change a value to preview the monitor.</p></div><button class="button small" data-all>${showAll?'Used only':'All 32'}</button></div><div class="signal-channels">${numbers.map(ch=>{
      const name=p.inputMap.number[ch-1],integer=isWholeNumberInput(name),gauge=layers.find(l=>l.kind==='gauge'&&channel(l.channel)===ch),raw=p.numbers[ch-1],v=integer?Math.round(raw):raw,min=Math.min(gauge?gauge.min:0,v),max=Math.max(gauge?gauge.max:100,v,min+1),step=integer?'1':'any';
      return `<label class="signal-card"><span><b>${escape(name)}</b><small>NUMBER ${ch}</small></span><div><input type="range" min="${min}" max="${max}" step="${step}" value="${v}" data-slider="${ch}" aria-label="${escape(name)} slider"><input type="number" step="${step}" value="${v}" data-value="${ch}" aria-label="${escape(name)} value"></div></label>`;
    }).join('')}${bools.map(ch=>`<label class="signal-bool"><input type="checkbox" data-bool-input="${ch}" ${p.bools[ch-1]?'checked':''}><span>${escape(p.inputMap.bool[ch-1])}<small>BOOLEAN ${ch}</small></span></label>`).join('')}${!numbers.length&&!bools.length?'<p class="signal-empty">Draw a number readout or gauge to preview a sensor. Or choose All 32.</p>':''}</div><div class="signal-outputs"><span>BOOLEAN OUTPUTS</span>${outputChannels.map(ch=>`<output data-output="${ch}" class="output-pill">${ch} <b>OFF</b></output>`).join('')||'<small>Add a touch zone or button to preview outputs.</small>'}</div>`;
    element.querySelector('[data-all]').onclick=()=>{showAll=!showAll;render()};
    for(const el of element.querySelectorAll('[data-slider],[data-value]'))el.oninput=()=>{if(el.value===''||!Number.isFinite(Number(el.value)))return;const ch=Number(el.dataset.slider||el.dataset.value),name=p.inputMap.number[ch-1],raw=Number(el.value),v=isWholeNumberInput(name)?Math.round(raw):Number(raw.toFixed(1));p.numbers[ch-1]=v;const range=element.querySelector(`[data-slider="${ch}"]`),number=element.querySelector(`[data-value="${ch}"]`);range.min=Math.min(Number(range.min),v);range.max=Math.max(Number(range.max),v);range.value=number.value=v;change()};
    for(const el of element.querySelectorAll('[data-bool-input]'))el.onchange=()=>{p.bools[el.dataset.boolInput-1]=el.checked;change()};
  }
  function updateOutputs(values){for(const el of element.querySelectorAll('[data-output]')){const on=!!values?.[Number(el.dataset.output)-1];el.classList.toggle('on',on);el.querySelector('b').textContent=on?'ON':'OFF'}}
  return {render,updateOutputs};
}
