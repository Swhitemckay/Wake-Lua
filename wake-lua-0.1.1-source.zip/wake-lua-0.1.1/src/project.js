import {defaultProject, MONITORS} from './drawing.js';

const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;
const clamp = (value, min, max, fallback = min) => Math.max(min, Math.min(max, finite(value, fallback)));
const color = (value, fallback) => /^#[\da-f]{6}$/i.test(value || '') ? value : fallback;
export const channel = value => Math.round(clamp(value, 1, 32));
export const inputValues = (values, boolean = false) => Array.from({length:32}, (_, i) => boolean ? values?.[i] === true : finite(values?.[i]));
export function projectPages(project) {
  if (!project.pages?.length) return [{id:'screen', name:'Main', layers:project.layers || [], links:[]}];
  return project.pages.map(page => ({...page, layers:page.id === project.currentPageId ? project.layers : page.layers || []}));
}
export function normalizeProject(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw Error('This file is not a monitor project.');
  if (!Array.isArray(raw.layers)) throw Error('This project is missing its drawing layers.');
  if (![raw.width, raw.height].every(n => Number.isInteger(n) && n >= 1 && n <= 1024)) throw Error('Monitor dimensions must be between 1 and 1,024 pixels.');
  const defaults = defaultProject(), p = {...defaults, ...raw};
  const normalizeLayers = layers => {
    if (!Array.isArray(layers) || layers.length > 2000) throw Error('Invalid layer list (maximum 2,000 layers).');
    const ids = new Set();
    return layers.map((l, i) => {
      if (!l || !['rect','circle','triangle','line','arc','brush','text','inputText','gauge','tape','button','zone'].includes(l.kind)) throw Error('This project contains an unsupported drawing layer.');
      let id = finite(l.id, i + 1); while(ids.has(id)) id++; ids.add(id);
      const layer = {...l, id, name:String(l.name || l.kind), color:color(l.color, '#c6d8cc'), x:clamp(l.x,-2048,2048,0), y:clamp(l.y,-2048,2048,0), w:clamp(l.w,-2048,2048,1), h:clamp(l.h,-2048,2048,1)};
      for (const key of ['cx','cy']) if (l[key] != null) layer[key] = clamp(l[key],-2048,2048,0);
      for (const key of ['borderColor','trackColor','pressedColor','textColor']) if (l[key]) layer[key] = color(l[key], '#31483c');
      if (l.kind === 'brush') {
        if (!Array.isArray(l.points) || l.points.length > 100000) throw Error('Invalid pixel stroke.');
        layer.points = l.points.filter(pt => Array.isArray(pt) && pt.length === 2 && pt.every(Number.isFinite)).map(pt => pt.map(v => Math.round(clamp(v,-2048,2048,0))));
      }
      if (['inputText','gauge','tape'].includes(l.kind)) layer.channel = channel(l.channel || 5);
      if (['button','zone'].includes(l.kind)) layer.outputChannel = channel(l.outputChannel || 1);
      if (l.kind === 'gauge') { layer.min = finite(l.min); layer.max = finite(l.max,100); }
      if(!raw.pixelGeometry&&(l.kind==='triangle'||['rect','button'].includes(l.kind)&&!l.fill)){layer.w+=1;layer.h+=1}
      if(!['line','arc'].includes(l.kind)){layer.w=Math.max(1,Math.round(layer.w));layer.h=Math.max(1,Math.round(layer.h))}
      layer.textSize=Math.round(clamp(l.textSize,1,8,1));
      if(l.kind==='tape'){layer.direction=l.direction==='vertical'?'vertical':'horizontal';layer.step=clamp(l.step,.01,100000,10);layer.spacing=clamp(l.spacing,4,1024,20);layer.wrap=clamp(l.wrap,0,100000,0);layer.marker=l.marker!==false}
      return layer;
    }).filter(l => l.kind !== 'brush' || l.points.length);
  };
  p.layers = normalizeLayers(p.layers);
  p.name = String(p.name || 'Untitled monitor'); p.background = color(p.background, defaults.background);
  p.monitor = MONITORS.some(m => m[0] === p.monitor) ? p.monitor : 'Custom';
  p.mode = p.mode === 'code' ? 'code' : 'draw'; p.code = String(p.code || ''); p.library = String(p.library || '');
  p.numbers = inputValues(p.numbers); p.bools = inputValues(p.bools,true);
  p.properties = Array.isArray(p.properties) ? p.properties.filter(v => v && typeof v.name === 'string') : [];
  p.settings = {...defaults.settings, ...(p.settings || {}), tps:clamp(p.settings?.tps,1,120,60)};
  p.inputMap = Object.fromEntries(['number','bool'].map(kind => [kind, Array.from({length:32},(_,i)=>String(p.inputMap?.[kind]?.[i] || defaults.inputMap[kind][i]))]));
  p.scenarios = Array.isArray(p.scenarios) ? p.scenarios.slice(0,20).filter(s=>s&&typeof s.name==='string').map(s=>({...s,numbers:inputValues(s.numbers),bools:inputValues(s.bools,true)})) : [];
  if (p.pages != null) {
    if (!Array.isArray(p.pages) || !p.pages.length || p.pages.length > 100) throw Error('A project needs 1–100 pages.');
    const ids = new Set();
    p.pages = p.pages.map((pg,i) => {
      if (!pg || ids.has(String(pg.id))) throw Error('Page identifiers must be unique.');
      const id = String(pg.id || 'page-'+(i+1)); ids.add(id);
      return {...pg, id, name:String(pg.name || 'Page '+(i+1)), layers:normalizeLayers(pg.layers || (i===0?p.layers:[])), links:(Array.isArray(pg.links)?pg.links:[]).filter(l=>l&&typeof l==='object').map(l=>({...l,label:String(l.label||'OPEN'),target:String(l.target||''),inputChannel:l.inputChannel?channel(l.inputChannel):null}))};
    });
    p.currentPageId = p.pages.some(pg=>pg.id===p.currentPageId) ? p.currentPageId : p.pages[0].id;
    const current = p.pages.find(pg=>pg.id===p.currentPageId);
    // The active editor is the most recent copy of its page.
    current.layers = structuredClone(p.layers);
  }
  p.pixelGeometry=1;
  return p;
}
export function usedNumberChannels(p) {
  const used = new Set(projectPages(p).flatMap(pg=>pg.layers).filter(l=>!l.hidden&&['inputText','gauge','tape'].includes(l.kind)).map(l=>channel(l.channel||5)));
  if(p.mode==='code') for(const match of (p.code+'\n'+p.library).matchAll(/input\s*\.\s*getNumber\s*\(\s*(\d+)\s*\)/g)) used.add(channel(match[1]));
  return [...used].sort((a,b)=>a-b);
}
export function captureScenario(p,name) { return {id:Date.now().toString(36),name:name.trim()||'Scenario',numbers:inputValues(p.numbers),bools:inputValues(p.bools,true)}; }
export function restoreScenario(p,scenario) { p.numbers=inputValues(scenario.numbers); p.bools=inputValues(scenario.bools,true); }
export function flowIssues(p) {
  const pages=projectPages(p), ids=new Set(pages.map(pg=>pg.id)), reached=new Set([pages[0].id]), issues=[];
  const valid = (pg,link) => ids.has(link.target) && (link.inputChannel || pg.layers.some(l=>['button','zone'].includes(l.kind)&&!l.hidden&&String(l.id)===String(link.buttonId)));
  for(let i=0;i<pages.length;i++) for(const pg of pages) if(reached.has(pg.id)) for(const l of pg.links||[]) if(valid(pg,l)) reached.add(l.target);
  for(const pg of pages) {
    if(!reached.has(pg.id)) issues.push(`${pg.name}: unreachable from the first page.`);
    for(const l of pg.links||[]) {
      if(!ids.has(l.target)) issues.push(`${pg.name} / ${l.label}: destination is missing.`);
      else if(!valid(pg,l)) issues.push(`${pg.name} / ${l.label}: connect a screen button or boolean input.`);
    }
  }
  return issues;
}

// Changing monitor orientation also reflows every page into the new canvas.
export function setProjectOrientation(p,rotated){
 rotated=!!rotated;if(!!p.rotated===rotated)return false;
 const monitor=MONITORS.find(m=>m[0]===p.monitor);if(!monitor)return false;
 const oldWidth=p.width,oldHeight=p.height,width=monitor[rotated?2:1],height=monitor[rotated?1:2],sx=width/oldWidth,sy=height/oldHeight;
 const resize=layers=>layers.map(layer=>{
  const l=structuredClone(layer);l.x*=sx;l.y*=sy;l.w*=sx;l.h*=sy;
  if(l.kind==='brush')l.points=l.points.map(([x,y])=>[x*sx,y*sy]);
  if(l.kind==='arc'){if(l.cx!=null)l.cx*=sx;if(l.cy!=null)l.cy*=sy}
  if(l.kind==='text'){l.box=true;l.w=Math.max(1,Math.min(l.w,width-l.x));l.h=Math.max(5,l.h);l.textSize=Math.max(1,Math.min(Number(l.textSize)||1,Math.floor(l.w/4)||1))}
  return l;
 });
 if(p.pages?.length){const pages=projectPages(p);p.pages=pages.map(pg=>({...pg,layers:resize(pg.layers)}));p.layers=structuredClone(p.pages.find(pg=>pg.id===p.currentPageId)?.layers||resize(p.layers))}
 else p.layers=resize(p.layers);
 p.width=width;p.height=height;p.rotated=rotated;return true;
}

export function addProjectScreen(p){
 if(!p.pages?.length){p.pages=[{id:'screen-1',name:'Screen 1',template:'Blank',layers:structuredClone(p.layers),links:[]}];p.currentPageId=p.pages[0].id}
 const current=p.pages.find(pg=>pg.id===p.currentPageId);if(current)current.layers=structuredClone(p.layers);
 const page={id:'screen-'+Date.now()+'-'+Math.random().toString(36).slice(2,7),name:'Screen '+(p.pages.length+1),template:'Blank',layers:[],links:[]};
 p.pages.push(page);p.currentPageId=page.id;p.layers=[];return page;
}
export function switchProjectScreen(p,delta){
 if(!p.pages?.length)return false;
 const index=p.pages.findIndex(pg=>pg.id===p.currentPageId),target=p.pages[index+delta];if(!target)return false;
 if(index>=0)p.pages[index].layers=structuredClone(p.layers);
 p.currentPageId=target.id;p.layers=structuredClone(target.layers);return true;
}
