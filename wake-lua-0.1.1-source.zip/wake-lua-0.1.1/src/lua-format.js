// Expand generated Lua at statement and block boundaries while keeping strings/comments intact.
export function formatLua(source){
 const tokens=[];let i=0;
 while(i<source.length){const c=source[i];if(/\s/.test(c)){i++;continue}
  if(source.startsWith('--',i)){let j=i+2;const open=source.slice(j).match(/^\[(=*)\[/);if(open){const close=']'+open[1]+']',e=source.indexOf(close,j+open[0].length);j=e<0?source.length:e+close.length}else while(j<source.length&&source[j]!=='\n')j++;tokens.push({v:source.slice(i,j),type:'comment'});i=j;continue}
  const long=source.slice(i).match(/^\[(=*)\[/);if(long){const close=']'+long[1]+']',e=source.indexOf(close,i+long[0].length),j=e<0?source.length:e+close.length;tokens.push({v:source.slice(i,j),type:'literal'});i=j;continue}
  if(c==='"'||c==="'"){let j=i+1;while(j<source.length){if(source[j]==='\\')j+=2;else if(source[j++]===c)break}tokens.push({v:source.slice(i,j),type:'literal'});i=j;continue}
  if(/[\p{L}_]/u.test(c)){let j=i+1;while(j<source.length&&/[\p{L}\p{N}_]/u.test(source[j]))j++;tokens.push({v:source.slice(i,j),type:'word'});i=j;continue}
  if(/[\d]/.test(c)){const number=source.slice(i).match(/^(?:0[xX][\da-fA-F]+(?:\.(?!\.)[\da-fA-F]*)?(?:[pP][+-]?\d+)?|\d+(?:\.(?!\.)\d*)?(?:[eE][+-]?\d+)?)/)?.[0]||c;tokens.push({v:number,type:'literal'});i+=number.length;continue}
  const op=['...','==','~=','<=','>=','..','//','<<','>>'].find(op=>source.startsWith(op,i));if(op){tokens.push({v:op,type:'symbol'});i+=op.length}else{tokens.push({v:c,type:'symbol'});i++}
 }
 let out='',indent=0,lineStart=true,previous='',pending='';const write=v=>{if(lineStart){out+='  '.repeat(Math.max(0,indent));lineStart=false}if(pending&&out&&!/[\s([{.:]$/.test(out))out+=' ';out+=v;pending=''};const newline=()=>{out=out.trimEnd();if(out&&!lineStart)out+='\n';lineStart=true;pending=''};
 const closing=new Set(['end','else','elseif','until']),opening=new Set(['then','do','function','repeat']);
 for(let n=0;n<tokens.length;n++){const {v,type}=tokens[n],prev=tokens[n-1]?.v||'';
  if(type==='comment'){if(!lineStart&&out&&!/[\s]$/.test(out))out+=' ';write(v);newline();previous=v;continue}
  if(closing.has(v)){newline();indent=Math.max(0,indent-1);write(v);if(v==='else'){newline();indent++}else if(v==='elseif'){pending=' '}else newline();previous=v;continue}
  if(v===';'){newline();previous=v;continue}
  if(v===','){write(v);pending=' ';previous=v;continue}
  if(v==='('||v==='['||v==='.'||v===':'){write(v);previous=v;continue}
  if(v===')'||v===']'||v==='}' ){pending='';write(v);previous=v;continue}
  if(v==='{'){if(prev!==''&&!/[({[.:]$/.test(out))pending=' ';write(v);previous=v;continue}
  if(v==='}') {write(v);previous=v;continue}
  if(type==='symbol'&&['=','+','-','*','/','%','^','#','<','>','~'].includes(v)){pending=' ';write(v);pending=' ';previous=v;continue}
  if(type==='symbol'&&v==='|'){write(v);previous=v;continue}
  if(previous===')'||previous===']'||previous==='}'||type==='word'||type==='literal')pending=' ';
  write(v);previous=v;
  if(opening.has(v)){newline();indent++}
 }
 return out.trim()+(out.trim()?'\n':'');
}
