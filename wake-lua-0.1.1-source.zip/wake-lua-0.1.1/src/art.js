const BLOCK_PIXELS = 9;
const MAX_BLOCKS = 2500;
const clampBlocks = value => Math.max(1, Math.min(100, Math.round(Number(value) || 1)));

export const escapeName = value => String(value || 'image')
  .replace(/[^\w -]+/g, '')
  .trim()
  .replace(/[ -]+/g, '_')
  .slice(0, 48) || 'image';

function xmlHeader() {
  return '<?xml version="1.0" encoding="UTF-8"?><vehicle data_version="2" is_advanced="true" is_static="false" bodies_id="2"><editor_placement_offset x="0" y="0" z="0"/><authors/><bodies><body unique_id="2"><initial_local_transform 00="1" 01="0" 02="0" 03="0" 10="0" 11="1" 12="0" 13="0" 20="0" 21="0" 22="1" 23="0" 30="0" 31="0" 32="0" 33="1"/><local_transform 00="1" 01="0" 02="0" 03="0" 10="0" 11="1" 12="0" 13="0" 20="0" 21="0" 22="1" 23="0" 30="0" 31="0" 32="0" 33="1"/><components>';
}

function signBlock(x, z, pixels) {
  return `<c d="sign_na" t="0"><o r="1,0,0,0,1,0,0,0,1" bc="FFFFFFFF" ac="FFFFFFFF" sc="6" custom_name=""><vp x="${x}" y="0" z="${z}"/><logic_slots><slot value="false"/></logic_slots>${pixels}</o></c>`;
}

export function xmlFor(imageData, widthBlocks, heightBlocks) {
  const { data, width } = imageData;
  const blockXml = [];
  // Stormworks stores paint cells in column-major order and mirrors the source
  // image horizontally so its visible sign face reads in the expected direction.
  for (let blockX = 0; blockX < widthBlocks; blockX++) {
    for (let blockY = 0; blockY < heightBlocks; blockY++) {
      const colors = [];
      for (let pixelX = 0; pixelX < BLOCK_PIXELS; pixelX++) {
        for (let pixelY = 0; pixelY < BLOCK_PIXELS; pixelY++) {
          const sourceX = width - 1 - (blockX * BLOCK_PIXELS + pixelX);
          const sourceY = blockY * BLOCK_PIXELS + pixelY;
          const index = (sourceY * width + sourceX) * 4;
          const gameIndex = pixelX + BLOCK_PIXELS * pixelY;
          colors.push(`<cc${gameIndex} r="${data[index]}" g="${data[index + 1]}" b="${data[index + 2]}" a="255"/>`);
        }
      }
      blockXml.push(signBlock(blockX, blockY, colors.join('')));
    }
  }
  return `${xmlHeader()}${blockXml.join('')}</components></body></bodies><logic_node_links/></vehicle>`;
}

export function createArtWorkspace({ download, toast }) {
  const $ = id => document.getElementById(id);
  const source = document.createElement('canvas');
  const sourceContext = source.getContext('2d', { willReadFrequently: true });
  const preview = $('artPreview');
  const previewContext = preview.getContext('2d', { willReadFrequently: true });
  let bitmap = null;
  let fileName = 'image';
  let sourceRatio = 1;
  let rendering = false;

  function message(text, error = false) {
    $('artStatus').textContent = text;
    $('artStatus').classList.toggle('error', error);
  }

  function dimensions(width = clampBlocks($('artWidth').value), height = clampBlocks($('artHeight').value)) {
    $('artWidth').value = width;
    $('artHeight').value = height;
    $('artDimensions').textContent = `${width} × ${height} blocks · ${width * 9} × ${height * 9} paint pixels`;
    return { width, height };
  }

  function render() {
    if (!bitmap || rendering) return;
    const { width, height } = dimensions();
    const blocks = width * height;
    if (blocks > MAX_BLOCKS) {
      $('artExport').disabled = true;
      $('artEmpty').hidden = false;
      message(`Choose 2,500 blocks or fewer (currently ${blocks.toLocaleString()}).`, true);
      return;
    }
    rendering = true;
    const pixelWidth = width * BLOCK_PIXELS;
    const pixelHeight = height * BLOCK_PIXELS;
    source.width = pixelWidth;
    source.height = pixelHeight;
    sourceContext.imageSmoothingEnabled = true;
    sourceContext.imageSmoothingQuality = 'high';
    const color = $('artBackground').value;
    sourceContext.fillStyle = color;
    sourceContext.fillRect(0, 0, pixelWidth, pixelHeight);

    // Keep image proportions with a centered fit, or fill the selected block grid.
    if ($('artKeepRatio').checked) {
      const scale = Math.min(pixelWidth / bitmap.width, pixelHeight / bitmap.height);
      const drawWidth = Math.max(1, Math.round(bitmap.width * scale));
      const drawHeight = Math.max(1, Math.round(bitmap.height * scale));
      sourceContext.drawImage(bitmap, Math.floor((pixelWidth - drawWidth) / 2), Math.floor((pixelHeight - drawHeight) / 2), drawWidth, drawHeight);
    } else {
      sourceContext.drawImage(bitmap, 0, 0, pixelWidth, pixelHeight);
    }

    if ($('artAdjust').checked) {
      const pixels = sourceContext.getImageData(0, 0, pixelWidth, pixelHeight);
      for (let i = 0; i < pixels.data.length; i += 4) {
        for (let channel = 0; channel < 3; channel++) {
          pixels.data[i + channel] = Math.max(0, Math.min(255, Math.round((pixels.data[i + channel] - 128) * 1.12 + 128)));
        }
      }
      sourceContext.putImageData(pixels, 0, 0);
    }

    preview.width = pixelWidth;
    preview.height = pixelHeight;
    previewContext.imageSmoothingEnabled = false;
    previewContext.drawImage(source, 0, 0);
    $('artEmpty').hidden = true;
    $('artExport').disabled = false;
    message(`${width * 9} × ${height * 9} paint pixels across ${blocks.toLocaleString()} blocks.`);
    rendering = false;
  }

  async function loadImage(file, name = file?.name || 'pasted-image.png') {
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(file.type)) {
      bitmap?.close?.();
      bitmap = null;
      $('artExport').disabled = true;
      message('Choose a PNG, JPEG, WebP, or GIF image.', true);
      return;
    }
    try {
      const nextBitmap = await createImageBitmap(file);
      bitmap?.close?.();
      bitmap = nextBitmap;
      fileName = name.replace(/\.[^.]+$/, '') || 'pasted-image';
      sourceRatio = bitmap.width / bitmap.height;
      const scale = Math.min(1, (100 * BLOCK_PIXELS) / bitmap.width, (100 * BLOCK_PIXELS) / bitmap.height, Math.sqrt((MAX_BLOCKS * BLOCK_PIXELS * BLOCK_PIXELS) / (bitmap.width * bitmap.height)));
      let width = clampBlocks(Math.ceil(bitmap.width * scale / BLOCK_PIXELS));
      let height = clampBlocks(Math.ceil(bitmap.height * scale / BLOCK_PIXELS));
      while (width * height > MAX_BLOCKS) {
        if (sourceRatio >= 1) width--;
        else height--;
      }
      $('artWidth').value = width;
      $('artHeight').value = height;
      $('artKeepRatio').checked = true;
      dimensions(width, height);
      render();
    } catch {
      bitmap?.close?.();
      bitmap = null;
      $('artExport').disabled = true;
      message('This image could not be opened. Try another PNG, JPEG, WebP, or GIF image.', true);
      toast('Could not read that image.');
    }
  }

  $('artImage').onchange = () => loadImage($('artImage').files?.[0]);
  $('artPaste').onclick = async () => {
    if (!navigator.clipboard?.read) {
      message('Clipboard image reading is unavailable here. Press ⌘V or Ctrl+V while Art is open.', true);
      return;
    }
    try {
      const clipboardItems = await navigator.clipboard.read();
      for (const item of clipboardItems) {
        const type = item.types.find(value => ['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(value));
        if (!type) continue;
        await loadImage(new File([await item.getType(type)], `pasted-image.${type.split('/')[1]}`, { type }), `pasted-image.${type.split('/')[1]}`);
        return;
      }
      message('No image found on the clipboard. Copy an image, then try again.', true);
    } catch {
      message('Clipboard access was unavailable. Press ⌘V or Ctrl+V while Art is open.', true);
    }
  };
  document.addEventListener('paste', event => {
    if ($('artWorkspace').hidden) return;
    const clipboardItems = Array.from(event.clipboardData?.items || []);
    const image = clipboardItems.find(item => item.type.startsWith('image/'));
    const file = image?.getAsFile() || event.clipboardData?.files?.[0];
    if (file) {
      event.preventDefault();
      void loadImage(file, file.name || 'pasted-image');
    }
  });

  function updateBlockSize(axis, commit = false) {
    const input = $(axis === 'width' ? 'artWidth' : 'artHeight');
    if (input.value === '' && !commit) return;
    const value = clampBlocks(input.value);
    input.value = value;
    if ($('artKeepRatio').checked && sourceRatio) {
      if (axis === 'width') $('artHeight').value = clampBlocks(Math.round(value / sourceRatio));
      else $('artWidth').value = clampBlocks(Math.round(value * sourceRatio));
    }
    render();
  }
  $('artWidth').oninput = () => updateBlockSize('width');
  $('artWidth').onchange = () => updateBlockSize('width', true);
  $('artHeight').oninput = () => updateBlockSize('height');
  $('artHeight').onchange = () => updateBlockSize('height', true);
  for (const id of ['artKeepRatio', 'artAdjust', 'artBackground']) $(id).onchange = render;
  $('artExport').onclick = () => {
    if (!bitmap) return;
    const { width, height } = dimensions();
    if (width * height > MAX_BLOCKS) return message(`Choose ${MAX_BLOCKS.toLocaleString()} blocks or fewer.`, true);
    try {
      const pixels = sourceContext.getImageData(0, 0, source.width, source.height);
      download(`${escapeName(fileName)}.xml`, xmlFor(pixels, width, height), 'application/xml;charset=utf-8');
      toast('Stormworks sign XML exported.');
    } catch {
      message('The XML could not be generated. Try a smaller image.', true);
    }
  };
}
