// Box dimensions always count occupied pixels, including both drag endpoints.
export function dragBox(start,end,square=false){
 let dx=end.x-start.x,dy=end.y-start.y;
 if(square){const size=Math.max(Math.abs(dx),Math.abs(dy));dx=(dx<0?-1:1)*size;dy=(dy<0?-1:1)*size}
 return {x:Math.min(start.x,start.x+dx),y:Math.min(start.y,start.y+dy),w:Math.abs(dx)+1,h:Math.abs(dy)+1};
}
export function triangleBox(start,end,square=false){return {...dragBox(start,end,square),flipY:end.y<start.y}}
export function circleBox(anchor,end){
 const diameter=Math.max(2,Math.round(Math.max(Math.abs(end.x-anchor.x),Math.abs(end.y-anchor.y))/2)*2);
 return {x:end.x<anchor.x?anchor.x-diameter+1:anchor.x,y:end.y<anchor.y?anchor.y-diameter+1:anchor.y,w:diameter,h:diameter};
}
export function reflectBox(layer,width,height,mx,my){return {...layer,x:mx?width-layer.x-layer.w:layer.x,y:my?height-layer.y-layer.h:layer.y}}
export function containsBox(layer,q){return q.x>=layer.x&&q.x<layer.x+layer.w&&q.y>=layer.y&&q.y<layer.y+layer.h}
