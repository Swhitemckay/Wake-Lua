const {app,BrowserWindow,protocol,net,dialog,Menu}=require('electron');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
protocol.registerSchemesAsPrivileged([{scheme:'wake',privileges:{standard:true,secure:true,supportFetchAPI:true,corsEnabled:true}}]);
let window;
function openWindow(){
 window=new BrowserWindow({width:1440,height:960,minWidth:900,minHeight:650,title:'Wake Lua',backgroundColor:'#202323',webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
 window.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 window.webContents.on('will-navigate',(event,url)=>{const target=new URL(url);if(target.protocol!=='wake:'||target.host!=='studio')event.preventDefault()});
 window.webContents.session.on('will-download',(_event,item)=>{
  const destination=dialog.showSaveDialogSync(window,{title:'Save export',defaultPath:item.getFilename()});
  if(destination)item.setSavePath(destination);else item.cancel();
 });
 window.loadURL('wake://studio/index.html');
}
if(!app.requestSingleInstanceLock())app.quit();else{
 app.on('second-instance',()=>{if(window){if(window.isMinimized())window.restore();window.focus()}});
 app.whenReady().then(()=>{
  const root=path.join(app.getAppPath(),'dist');
  protocol.handle('wake',request=>{
   const url=new URL(request.url);
   const file=path.resolve(root,'.'+decodeURIComponent(url.pathname));
   if(url.host!=='studio'||!file.startsWith(root+path.sep))return new Response('Not found',{status:404});
   return net.fetch(pathToFileURL(file).href);
  });
  Menu.setApplicationMenu(Menu.buildFromTemplate([
   ...(process.platform==='darwin'?[{role:'appMenu'}]:[]),
   {label:'Edit',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'},{role:'selectAll'}]},
   {label:'View',submenu:[{role:'reload'},{role:'resetZoom'},{role:'zoomIn'},{role:'zoomOut'},{role:'togglefullscreen'}]},
   {role:'windowMenu'}
  ]));
  openWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)openWindow()});
 });
 app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
}
