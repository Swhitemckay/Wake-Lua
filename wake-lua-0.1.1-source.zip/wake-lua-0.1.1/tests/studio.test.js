import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {performance} from 'node:perf_hooks';
import {defaultProject,featureShowcaseProject,generateLua,layerCommands,renderCommands,compactCommands} from '../src/drawing.js';
import {splitPageExport,optimizedSource,freePageChannels,LUA_LIMIT} from '../src/lua-export.js';
import {normalizeProject,usedNumberChannels,captureScenario,restoreScenario,flowIssues,setProjectOrientation,addProjectScreen,switchProjectScreen} from '../src/project.js';
import {formatLua} from '../src/lua-format.js';
import {isWholeNumberInput} from '../src/signals.js';
const workerSource=readFileSync(new URL('../dist/assets/lua-worker.js',import.meta.url),'utf8');
function runtime(project,code=generateLua(project)){
 const messages=[],self={postMessage:value=>messages.push(JSON.parse(JSON.stringify(value)))};
 vm.runInNewContext(workerSource,{self,performance,console,TextEncoder,TextDecoder,setTimeout,clearTimeout});
 const send=data=>{self.onmessage({data});return messages.at(-1)};
 const init=send({type:'init',code,library:'',width:project.width,height:project.height,numbers:project.numbers,bools:project.bools});
 assert.equal(init.type,'ready',init.error);
 return {frame:(numbers=project.numbers,bools=project.bools)=>send({type:'frame',numbers,bools,steps:1}),send};
}
const projectWith=layers=>({...defaultProject(),layers});
const rect=(id,color='#ffffff')=>({id,name:'Rect '+id,kind:'rect',x:1,y:1,w:8,h:8,fill:true,color});
const zone=(id,ch=1,x=0)=>({...rect(id),kind:'zone',x,y:0,w:10,h:10,outputChannel:ch});
const touch=(x,y,pressed=true)=>({numbers:[96,64,x,y,...Array(28).fill(0)],bools:[pressed,...Array(31).fill(false)]});
const runTouch=(r,x,y,pressed=true)=>{const t=touch(x,y,pressed);return r.frame(t.numbers,t.bools)};

test('blank starter and 3×3 showcase compile and run',()=>{
 const blank=defaultProject(),blankFrame=runtime(blank).frame();assert.deepEqual(blankFrame.commands.map(command=>command.name),['setColor','drawClear']);
 const showcase=featureShowcaseProject(),code=generateLua(showcase),frame=runtime(showcase).frame();assert.ok(code.length<=LUA_LIMIT,`${showcase.name}: ${code.length}`);assert.equal(frame.type,'frame',frame.error);assert.ok(frame.commands.length>10);
});
test('the sole bundled showcase is a 3×3 project with drawing, sensor and touch features',()=>{
 const bundled=JSON.parse(readFileSync(new URL('../showcases/3x3-feature-showcase.json',import.meta.url),'utf8')),showcase=featureShowcaseProject();
 assert.deepEqual(bundled,showcase);assert.equal(showcase.monitor,'3x3');assert.equal(showcase.width,96);assert.equal(showcase.height,96);
 assert.ok(showcase.layers.some(layer=>layer.kind==='line'));assert.ok(showcase.layers.some(layer=>layer.kind==='triangle'));assert.ok(showcase.layers.some(layer=>layer.kind==='inputText'));assert.ok(showcase.layers.some(layer=>layer.kind==='button'));assert.equal(showcase.settings.touch,true);
});
test('Lua formatter preserves long bracket strings, comments, and executable behavior',()=>{
 const source='local payload=[=[first line\nsecond line]=]\n--[=[comment\nkept]=]\nfunction onTick() output.setNumber(1,#payload) end';
 const formatted=formatLua(source);assert.match(formatted,/\[=\[first line\nsecond line\]=\]/);assert.match(formatted,/--\[=\[comment\nkept\]=\]/);
 const project=defaultProject(),before=runtime(project,source).frame(),after=runtime(project,formatted).frame();assert.equal(after.numbers[0],before.numbers[0]);
});
test('showcase fuel readout and gauge share channel 7',()=>{const p=featureShowcaseProject();assert.equal(p.layers.find(l=>l.name==='Fuel gauge').channel,7);assert.equal(p.layers.find(l=>l.name==='Fuel level').channel,7);assert.deepEqual(usedNumberChannels(p),[5,6,7,8])});
test('all 32 number channels round-trip negative, fractional, zero, and high values',()=>{
 const p=defaultProject(),code='function onTick() for i=1,32 do output.setNumber(i,input.getNumber(i)) end end',r=runtime(p,code),samples=[-1000000.5,-0.25,0,0.25,1000000.5];
 for(let ch=1;ch<=32;ch++)for(const sample of samples){const numbers=Array(32).fill(0);numbers[ch-1]=sample;const frame=r.frame(numbers);assert.equal(frame.type,'frame');assert.equal(frame.numbers[ch-1],sample,`channel ${ch}, value ${sample}`)}
});
test('count and ammunition inputs are whole-number channels',()=>{for(const name of ['AIM-9 count','AMRAAM left count','Ammo quantity','Rounds','Missiles'])assert.equal(isWholeNumberInput(name),true,name);for(const name of ['Engine RPS','Altitude','Coolant temperature'])assert.equal(isWholeNumberInput(name),false,name)});
test('export preserves order of static and sensor layers',()=>{
 const p=projectWith([{...rect(1),kind:'inputText',channel:5,prefix:'RPS ',decimals:1},rect(2,'#ff0000'),{...rect(3),kind:'inputText',channel:6}]);
 const cmds=runtime(p).frame().commands;assert.deepEqual(cmds.filter(c=>['drawText','drawRectF'].includes(c.name)).map(c=>c.name),['drawText','drawRectF','drawText']);
});
test('static rectangle compaction merges only touching same-color runs',()=>{
 const input=[{name:'setColor',args:[255,255,255,255]},...[0,1,2].map(x=>({name:'drawRectF',args:[x,4,1,1]})),{name:'drawRectF',args:[5,4,1,1]},{name:'setColor',args:[255,0,0,255]},{name:'drawRectF',args:[6,4,1,1]}];
 const compact=compactCommands(input);assert.deepEqual(compact,[{name:'setColor',args:[255,255,255]},{name:'drawRectF',args:[0,4,3,1]},{name:'drawRectF',args:[5,4,1,1]},{name:'setColor',args:[255,0,0]},{name:'drawRectF',args:[6,4,1,1]}]);
});
test('adjacent same-color layers compact without changing their rendered pixels',()=>{
 const layers=Array.from({length:12},(_,i)=>({...rect(i+1),x:i,y:8,w:1,h:1,color:'#7ab4d0'})),p=projectWith(layers),result=runtime(p).frame(),reference=[{name:'setColor',args:[0,0,0,255]},{name:'drawClear',args:[]},...layers.flatMap(l=>layerCommands(l))];
 assert.deepEqual(pixels(result.commands),pixels(reference));assert.deepEqual(result.commands.filter(c=>c.name==='drawRectF').map(c=>c.args),[[0,8,12,1]]);
});
test('zone is invisible in drawing primitives and exported onDraw',()=>{const z=zone(1);assert.deepEqual(layerCommands(z),[]);const p=projectWith([z]);const f=runtime(p).frame();assert.deepEqual(f.commands.map(c=>c.name),['setColor','drawClear'])});
test('zone activates selected boolean output and releases',()=>{const r=runtime(projectWith([zone(1,12)]));assert.equal(runTouch(r,5,5).bools[11],true);assert.equal(runTouch(r,5,5,false).bools[11],false);assert.equal(runTouch(r,10,5).bools[11],false)});
test('buttons sharing an output do not cancel one another',()=>{const r=runtime(projectWith([zone(1,3),zone(2,3,20)]));assert.equal(runTouch(r,5,5).bools[2],true);assert.equal(runTouch(r,25,5).bools[2],true);assert.equal(runTouch(r,50,5).bools[2],false)});
test('topmost overlapping touch control wins',()=>{const r=runtime(projectWith([zone(1,1),zone(2,2)]));const f=runTouch(r,5,5);assert.equal(f.bools[0],false);assert.equal(f.bools[1],true)});
test('hidden controls do not receive touch',()=>{const r=runtime(projectWith([{...zone(1,3),hidden:true}]));assert.equal(runTouch(r,5,5).bools[2],false)});
test('touch navigation changes page only once until released',()=>{
 const a=zone(1),b=zone(2,2);const p=projectWith([a]);p.pages=[{id:'a',layers:[a,{...rect(3),kind:'text',text:'FIRST'}],links:[{buttonId:1,target:'b'}]},{id:'b',layers:[b,{...rect(4),kind:'text',text:'SECOND'}],links:[{buttonId:2,target:'a'}]}];
 const r=runtime(p);assert.ok(runTouch(r,5,5).commands.some(c=>c.args.includes('SECOND')));assert.ok(runTouch(r,5,5).commands.some(c=>c.args.includes('SECOND')));runTouch(r,5,5,false);assert.ok(runTouch(r,5,5).commands.some(c=>c.args.includes('FIRST')));
});
test('boolean input navigation responds to a rising edge',()=>{
 const p=projectWith([]);p.pages=[{id:'a',layers:[{...rect(1),kind:'text',text:'FIRST'}],links:[{inputChannel:4,target:'b'}]},{id:'b',layers:[{...rect(2),kind:'text',text:'SECOND'}],links:[]}];const r=runtime(p),bools=Array(32).fill(false);bools[3]=true;assert.ok(r.frame(p.numbers,bools).commands.some(c=>c.args.includes('SECOND')));
});
test('active drawing is authoritative when exporting pages',()=>{const p=projectWith([{...rect(1),kind:'text',text:'EDITED'}]);p.currentPageId='a';p.pages=[{id:'a',layers:[],links:[]}];assert.ok(runtime(p).frame().commands.some(c=>c.args.includes('EDITED')))});
test('gauge rounds consistently and supports zero and negative limits',()=>{for(const [min,max,value] of [[-100,0,-50],[0,100,33],[0,0,0]]){const l={...rect(1),kind:'gauge',w:7,min,max,channel:5};const p=projectWith([l]);p.numbers[4]=value;const expected=layerCommands(l,p.numbers).filter(c=>c.name==='drawRectF').at(-1);assert.deepEqual(runtime(p).frame().commands.filter(c=>c.name==='drawRectF').at(-1),expected)}});
test('text export handles quotes, slashes, control characters and Unicode',()=>{const value='"path\\name"\n\t\u0001 café';const p=projectWith([{...rect(1),kind:'text',text:value}]);assert.equal(runtime(p).frame().commands.find(c=>c.name==='drawText').args[2],value)});
test('diagonal lines rasterize to fully opaque integer pixels',()=>{const commands=layerCommands({...rect(1),kind:'line',x:0,y:0,w:6,h:3});assert.ok(commands.slice(1).every(c=>c.name==='drawRectF'&&c.args.every(Number.isInteger)));assert.equal(commands.slice(1).reduce((n,c)=>n+c.args[2],0),7)});
test('runtime drawLine uses pixels rather than antialiased strokes',()=>{let pixels=0;const ctx={canvas:{width:10,height:10},save(){},restore(){},setTransform(){},clearRect(){},fillRect(){pixels++},beginPath(){throw Error('Antialiased line')}};renderCommands(ctx,[{name:'drawLine',args:[0,0,6,3]}],10,10);assert.ok(pixels>2)});
test('normalization repairs missing optional fields and nonfinite inputs',()=>{const p=normalizeProject({width:32,height:32,layers:[],settings:{},numbers:[Infinity],bools:[],inputMap:{}});assert.equal(p.numbers.length,32);assert.equal(p.numbers[0],0);assert.equal(p.inputMap.number.length,32);assert.equal(p.settings.tps,60);assert.deepEqual(p.properties,[])});
test('invalid projects and duplicate page IDs are rejected',()=>{for(const p of [null,{}, {width:-1,height:32,layers:[]},{width:32,height:32,layers:[{kind:'unknown'}]},{...defaultProject(),pages:[{id:'a',layers:[]},{id:'a',layers:[]}]}])assert.throws(()=>normalizeProject(p))});
test('saved input scenarios copy and restore all channels without aliasing',()=>{const p=defaultProject(),s=captureScenario(p,' Cruise ');p.numbers[4]=50;restoreScenario(p,s);assert.equal(p.numbers[4],12);assert.equal(s.name,'Cruise');p.numbers[4]=99;assert.equal(s.numbers[4],12)});
test('flow validation catches broken, unbound and unreachable links',()=>{const p=projectWith([]);p.pages=[{id:'a',name:'Main',layers:[],links:[{label:'Broken',target:'missing'},{label:'Unbound',target:'b'}]},{id:'b',name:'Details',layers:[],links:[]}];assert.equal(flowIssues(p).length,3);p.pages[0].links=[{inputChannel:3,target:'b'}];assert.deepEqual(flowIssues(p),[])});
test('Lua errors and invalid channels return readable errors',()=>{const p=defaultProject();const r=runtime(p,'function onTick() input.getNumber(33) end');const error=r.frame();assert.equal(error.type,'error');assert.match(error.error,/integer from 1 to 32/)});
test('infinite Lua loops are interrupted',()=>{const r=runtime(defaultProject(),'function onTick() while true do end end');const error=r.frame();assert.equal(error.type,'error');assert.match(error.error,/Execution budget exceeded/)});
test('Lua property values and outputs work',()=>{const r=runtime(defaultProject(),'function onTick() output.setNumber(8,input.getNumber(5)*2) output.setBool(9,true) end');const f=r.frame();assert.equal(f.numbers[7],24);assert.equal(f.bools[8],true)});


test('standard backgrounds are pure black',()=>{assert.equal(defaultProject().background,'#000000');assert.equal(featureShowcaseProject().background,'#000000')});
test('static screens omit page state and unused APIs',()=>{const code=generateLua(projectWith([rect(1)]));assert.ok(!code.includes('onTick'));assert.ok(!code.includes('drawText'));assert.ok(!code.includes('drawRect,'));assert.ok(code.length<150)});
test('split scripts synchronize navigation and only the active page draws',()=>{
 const z=zone(1,12),p=projectWith([z]);p.pages=[{id:'a',name:'First',layers:[z,{...rect(2),kind:'text',text:'FIRST'}],links:[{buttonId:1,target:'b'}]},{id:'b',name:'Second',layers:[{...rect(3),kind:'text',text:'SECOND'}],links:[]}];
 const bundle=splitPageExport(p,32);assert.ok(bundle.valid);const router=runtime(p,bundle.blocks[0].code),t=touch(5,5),route=router.frame(t.numbers,t.bools);assert.equal(route.numbers[31],2);assert.equal(route.bools[11],true);assert.equal(route.commands.length,0);
 const merged=[...t.numbers];merged[31]=route.numbers[31];const renders=bundle.blocks.slice(1).map(block=>runtime(p,block.code).frame(merged,t.bools));assert.equal(renders[0].commands.length,0);assert.ok(renders[1].commands.some(c=>c.args.includes('SECOND')));assert.ok(renders.every(frame=>frame.bools.every(v=>!v)));
});
test('page selection never steals a sensor or touch channel',()=>{const p=projectWith([{...rect(1),kind:'inputText',channel:32}]);assert.equal(freePageChannels(p)[0],31);assert.throws(()=>splitPageExport(p,32));assert.throws(()=>splitPageExport(p,3))});
test('custom scripts remain single scripts and include minified helpers',()=>{const p=defaultProject();p.mode='code';p.library='-- helper\nfunction helper() return 10 end';p.code='function onTick() output.setNumber(1,helper()) end';assert.throws(()=>splitPageExport(p));const f=runtime(p,optimizedSource(p)).frame();assert.equal(f.numbers[0],10)});
test('multiple pages exceeding the combined limit fit separate blocks',()=>{
 const p=projectWith([]);p.pages=Array.from({length:3},(_,pi)=>({id:'p'+pi,name:'Page '+pi,links:[],layers:Array.from({length:55},(_,i)=>({...rect(i),kind:'text',x:i%90,y:i%60,text:'SENSOR '+pi+' VALUE '+i}))}));const combined=generateLua(p);assert.ok(combined.length>4096);const bundle=splitPageExport(p);assert.ok(bundle.valid);for(const block of bundle.blocks)assert.equal(runtime(p,block.code).frame().type,'frame');
});
test('oversized individual pages are flagged instead of silently truncated',()=>{const p=projectWith(Array.from({length:180},(_,i)=>({...rect(i),kind:'text',text:'LONG VALUE '+i})));for(let i=p.layers.length;generateLua(p).length<=LUA_LIMIT;i++)p.layers.push({...rect(i),kind:'text',text:'LONG VALUE '+i});const bundle=splitPageExport(p);assert.equal(bundle.valid,false);assert.ok(bundle.blocks[1].overLimit)});

test('generation cache updates after drawing changes',()=>{const p=projectWith([rect(1)]),before=generateLua(p);assert.equal(generateLua(p),before);p.layers[0].x=15;assert.notEqual(generateLua(p),before)});

test('portrait orientation reflows all pages and touch zones into the canvas',()=>{const p=projectWith([{...rect(1),x:75,y:40,w:20,h:15},zone(2,12,70)]);p.pages=[{id:'a',layers:p.layers,links:[]},{id:'b',layers:[{...rect(3),x:80,y:50,w:10,h:10}],links:[]}];p.currentPageId='a';assert.equal(setProjectOrientation(p,true),true);assert.equal(p.width,64);assert.equal(p.height,96);for(const page of p.pages)for(const l of page.layers){assert.ok(l.x+l.w<=p.width);assert.ok(l.y+l.h<=p.height)}assert.equal(p.layers[1].outputChannel,12);assert.equal(runtime(p).frame().type,'frame');assert.equal(setProjectOrientation(p,true),false);assert.equal(setProjectOrientation(p,false),true);assert.equal(p.width,96);assert.equal(p.height,64)});

test('screen controls preserve drawings while adding and changing screens',()=>{const p=projectWith([rect(1)]);const second=addProjectScreen(p);assert.equal(p.pages.length,2);assert.equal(p.currentPageId,second.id);assert.deepEqual(p.layers,[]);p.layers.push(zone(2,12));assert.equal(switchProjectScreen(p,-1),true);assert.equal(p.layers[0].id,1);assert.equal(switchProjectScreen(p,-1),false);assert.equal(switchProjectScreen(p,1),true);assert.equal(p.layers[0].outputChannel,12);assert.equal(switchProjectScreen(p,1),false)});

import {dragBox,triangleBox,circleBox,reflectBox,containsBox} from '../src/geometry.js';
function pixels(commands,w=96,h=64){const out=new Set();const ctx={canvas:{width:w,height:h},save(){},restore(){},setTransform(){},clearRect(){},fillRect(x,y,ww,hh){assert.ok([x,y,ww,hh].every(Number.isInteger),'whole pixel coordinates');if(this.fillStyle==='black'||this.fillStyle==='rgba(0,0,0,1)')return;for(let py=y;py<y+hh;py++)for(let px=x;px<x+ww;px++)out.add(px+','+py)}};renderCommands(ctx,commands,w,h);return out}
test('rectangle drags include every pixel to each edge, in either direction',()=>{for(const [a,b] of [[{x:0,y:0},{x:31,y:31}],[{x:31,y:31},{x:0,y:0}],[{x:0,y:31},{x:31,y:0}]]){const box=dragBox(a,b);assert.deepEqual(box,{x:0,y:0,w:32,h:32});for(const fill of [true,false]){const l={...rect(1),...box,fill};const pts=pixels(layerCommands(l));for(const point of ['0,0','31,31','31,0','0,31'])assert.ok(pts.has(point));assert.ok(!pts.has('32,32'));assert.equal(containsBox(l,{x:32,y:31}),false)}}});
test('fill toggles preserve dimensions and symmetry of rectangles',()=>{for(const fill of [true,false])for(const [mx,my] of [[true,false],[false,true],[true,true]]){const l={...rect(1),x:3,y:5,w:11,h:7,fill},m=reflectBox(l,96,64,mx,my),actual=pixels(layerCommands(m)),expected=new Set([...pixels(layerCommands(l))].map(k=>{let [x,y]=k.split(',').map(Number);return (mx?95-x:x)+','+(my?63-y:y)}));assert.deepEqual(actual,expected)}});
test('legacy outlined geometry migrates once without changing visible bounds',()=>{const raw=projectWith([{...rect(1),fill:false}]);delete raw.pixelGeometry;const p=normalizeProject(raw);assert.equal(p.layers[0].w,9);assert.deepEqual(normalizeProject(p).layers,p.layers);assert.deepEqual(layerCommands(p.layers[0]).at(-1).args,[1,1,8,8])});
test('circle resizing stays round and even from every corner',()=>{for(const end of [{x:12,y:8},{x:-12,y:8},{x:12,y:-8},{x:-12,y:-8}]){const c=circleBox({x:0,y:0},end);assert.equal(c.w,c.h);assert.equal(c.w%2,0)}});
test('triangle drag direction flips the apex up or down',()=>{const down=triangleBox({x:4,y:2},{x:18,y:20}),up=triangleBox({x:4,y:20},{x:18,y:2});assert.equal(down.flipY,false);assert.equal(up.flipY,true);const top=layerCommands({...rect(1),...down,kind:'triangle'}).find(c=>c.name==='drawTriangleF').args,bottom=layerCommands({...rect(2),...up,kind:'triangle'}).find(c=>c.name==='drawTriangleF').args;assert.ok(top[1]<top[3]);assert.ok(bottom[1]>bottom[3])});
test('all element kinds compile and render after a project round trip',()=>{for(const kind of ['rect','circle','triangle','line','arc','brush','text','inputText','gauge','tape','button','zone'])for(const fill of [true,false]){const l={...rect(1),kind,fill,points:[[0,0],[1,1]],text:'TEST',channel:5,outputChannel:2,textSize:2,w:40,h:16};const p=normalizeProject(projectWith([l])),f=runtime(p).frame();assert.equal(f.type,'frame',kind+': '+f.error);assert.doesNotThrow(()=>pixels(f.commands),kind)}});
test('HUD tapes clip numbers and match live Lua at positive, negative and wrapped values',()=>{for(const direction of ['horizontal','vertical'])for(const value of [-15,0,102,359,365]){const l={...rect(1),kind:'tape',x:7,y:9,w:54,h:34,direction,step:10,spacing:16,wrap:360,textSize:2,channel:5};const p=projectWith([l]);p.numbers[4]=value;const expected=pixels(layerCommands(l,p.numbers));const actual=pixels(runtime(p).frame().commands);assert.deepEqual(actual,expected,`${direction} ${value}`);for(const key of actual){const [x,y]=key.split(',').map(Number);assert.ok(x>=7&&x<61&&y>=9&&y<43)}}});
test('large readouts preserve prefix, decimals, suffix and changing values in Lua',()=>{const l={...rect(1),kind:'inputText',channel:5,textSize:3,prefix:'SPD ',suffix:' M/S',decimals:1};const p=projectWith([l]),r=runtime(p);for(const v of [-12.3,0,99.8]){p.numbers[4]=v;assert.deepEqual(pixels(r.frame(p.numbers).commands),pixels(layerCommands(l,p.numbers)))}});
