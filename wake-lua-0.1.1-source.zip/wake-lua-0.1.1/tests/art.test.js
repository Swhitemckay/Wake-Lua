import test from 'node:test';
import assert from 'node:assert/strict';
import {escapeName, xmlFor} from '../src/art.js';

function image(width, height, colorAt = () => [0, 0, 0, 255]) {
  const data = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      data.set(colorAt(x, y), (y * width + x) * 4);
    }
  }
  return {data, width};
}

function signs(xml) {
  return [...xml.matchAll(/<c d="sign_na".*?<\/c>/gs)].map(([match]) => match);
}

test('Art XML creates one 9×9 paint sign for each selected block', () => {
  const blocks = signs(xmlFor(image(18, 18), 2, 2));
  assert.equal(blocks.length, 4);
  for (const block of blocks) {
    assert.equal([...block.matchAll(/<cc\d+ /g)].length, 81);
    assert.match(block, /<vp x="\d+" y="0" z="\d+"\/>/);
  }
});

test('Art XML preserves the intended horizontal mirror and block order', () => {
  const source = image(18, 9, x => x === 0 ? [255, 0, 0, 255] : x === 17 ? [0, 0, 255, 255] : [0, 0, 0, 255]);
  const blocks = signs(xmlFor(source, 2, 1));
  assert.equal(blocks.length, 2);
  assert.match(blocks[0], /<cc0 r="0" g="0" b="255" a="255"\/>/);
  assert.match(blocks[1], /<cc8 r="255" g="0" b="0" a="255"\/>/);
});

test('Art export filenames are safe and retain readable names', () => {
  assert.equal(escapeName('my ship sign'), 'my_ship_sign');
  assert.equal(escapeName('../../bad<>name'), 'badname');
  assert.equal(escapeName(''), 'image');
});
