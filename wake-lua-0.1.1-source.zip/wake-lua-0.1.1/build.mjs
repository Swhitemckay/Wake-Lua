import {build} from 'esbuild';
import {copyFileSync,mkdirSync,writeFileSync} from 'node:fs';
mkdirSync('dist/assets',{recursive:true});
await build({entryPoints:['src/main.js'],outfile:'dist/assets/app.js',bundle:true,minify:true,format:'esm',platform:'browser',legalComments:'linked'});
await build({entryPoints:['src/lua-worker.js'],outfile:'dist/assets/lua-worker.js',bundle:true,minify:true,format:'iife',platform:'browser',define:{'process.env.FENGARICONF':'undefined','process':'undefined'},legalComments:'linked'});
copyFileSync('src/index.html','dist/index.html');copyFileSync('src/style.css','dist/assets/style.css');
writeFileSync('dist/assets/THIRD_PARTY.txt','Wake Lua uses Fengari (MIT), CodeMirror (MIT), Lucide (ISC), luamin (MIT) and fflate (MIT). License notices are retained alongside the bundles.');
console.log('Built monitor studio and isolated Lua runtime.');
