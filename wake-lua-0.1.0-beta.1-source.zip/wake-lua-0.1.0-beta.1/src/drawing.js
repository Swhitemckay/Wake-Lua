import luamin from 'luamin';
export const MONITORS=[['1x1',32,32],['2x1',64,32],['2x2',64,64],['3x1',96,32],['3x2',96,64],['3x3',96,96],['5x3',160,96],['9x5',288,160],['Seat HUD',256,192],['Small HUD',32,32],['Large HUD',96,96]];
const glyphs={A:['010','101','111','101','101'],B:['110','101','110','101','110'],C:['011','100','100','100','011'],D:['110','101','101','101','110'],E:['111','100','110','100','111'],F:['111','100','110','100','100'],G:['011','100','101','101','011'],H:['101','101','111','101','101'],I:['111','010','010','010','111'],J:['001','001','001','101','010'],K:['101','101','110','101','101'],L:['100','100','100','100','111'],M:['10001','11011','10101','10001','10001'],N:['1001','1101','1011','1001','1001'],O:['010','101','101','101','010'],P:['110','101','110','100','100'],Q:['010','101','101','111','011'],R:['110','101','110','101','101'],S:['011','100','010','001','110'],T:['111','010','010','010','010'],U:['101','101','101','101','111'],V:['101','101','101','101','010'],W:['10001','10001','10101','11011','10001'],X:['101','101','010','101','101'],Y:['101','101','010','010','010'],Z:['111','001','010','100','111'],'0':['111','101','101','101','111'],'1':['010','110','010','010','111'],'2':['110','001','010','100','111'],'3':['110','001','010','001','110'],'4':['101','101','111','001','001'],'5':['111','100','110','001','110'],'6':['011','100','111','101','111'],'7':['111','001','010','010','010'],'8':['111','101','111','101','111'],'9':['111','101','111','001','110'],' ':['000','000','000','000','000'],'.':['0','0','0','0','1'],':':['0','1','0','1','0'],'-':['000','000','111','000','000'],'+':['000','010','111','010','000'],'/':['001','001','010','100','100'],'%':['101','001','010','100','101'],'!':['1','1','1','0','1'],'?':['110','001','010','000','010'],'(' :['01','10','10','10','01'],')':['10','01','01','01','10'],'[':['11','10','10','10','11'],']':['11','01','01','01','11'],'=':['000','111','000','111','000'],'_':['000','000','000','000','111'],'<':['001','010','100','010','001'],'>':['100','010','001','010','100'],',':['00','00','00','01','10'],'*':['101','010','111','010','101'],'°':['11','11','00','00','00']};
export function textWidth(s){return [...String(s).toUpperCase()].reduce((n,c)=>n+Math.max(4,(glyphs[c]?.[0].length||3)+1),0)}
export function drawPixelText(ctx,x,y,value){let sx=Math.round(x);let line=0;for(const c of String(value).toUpperCase()){if(c==='\n'){sx=Math.round(x);line+=6;continue}const g=glyphs[c]||glyphs['?'];for(let j=0;j<5;j++)for(let k=0;k<g[j].length;k++)if(g[j][k]==='1')ctx.fillRect(sx+k,Math.round(y)+line+j,1,1);sx+=Math.max(4,g[0].length+1)}}
export const rgba=h=>{const v=h.replace('#','');return [parseInt(v.slice(0,2),16),parseInt(v.slice(2,4),16),parseInt(v.slice(4,6),16),255]};
function pixelCircle(ctx,cx,cy,r,filled){if(!Number.isInteger(cx)||!Number.isInteger(cy)){cx=Math.round(cx*2)/2;cy=Math.round(cy*2)/2;r=Math.max(0,Math.round(r));const outer=r*r,inner=Math.max(0,r-1)**2;for(let y=Math.ceil(cy-r-.5);y<=Math.floor(cy+r+.5);y++)for(let x=Math.ceil(cx-r-.5);x<=Math.floor(cx+r+.5);x++){const distance=(x-cx)**2+(y-cy)**2;if(distance<=outer&&(filled||distance>=inner))ctx.fillRect(x,y,1,1)}return}cx=Math.round(cx);cy=Math.round(cy);r=Math.max(0,Math.round(r));let x=r,y=0,error=1-r;const dot=(a,b)=>ctx.fillRect(cx+a,cy+b,1,1),span=(a,b,yy)=>ctx.fillRect(cx+a,cy+yy,b-a+1,1);while(x>=y){if(filled){span(-x,x,y);if(y)span(-x,x,-y);span(-y,y,x);if(x)span(-y,y,-x)}else{for(const [a,b] of [[x,y],[y,x],[-y,x],[-x,y],[-x,-y],[-y,-x],[y,-x],[x,-y]])dot(a,b)}y++;if(error<0)error+=2*y+1;else{x--;error+=2*(y-x)+1}}}
function pixelTriangle(ctx,args,filled){const [x,y,b,c,d,e]=args.map(Math.round),vertices=[[x,y],[b,c],[d,e]];if(filled){const cross=(ax,ay,bx,by,px,py)=>(bx-ax)*(py-ay)-(by-ay)*(px-ax);const area=cross(x,y,b,c,d,e);if(area)for(let yy=Math.min(y,c,e);yy<=Math.max(y,c,e);yy++){let start=null,end=null;for(let xx=Math.min(x,b,d);xx<=Math.max(x,b,d);xx++){const signs=[cross(x,y,b,c,xx,yy),cross(b,c,d,e,xx,yy),cross(d,e,x,y,xx,yy)];if(signs.every(v=>v>=0)||signs.every(v=>v<=0)){start??=xx;end=xx}}if(start!==null)ctx.fillRect(start,yy,end-start+1,1)}}for(let i=0;i<3;i++)for(const pixel of linePixels(...vertices[i],...vertices[(i+1)%3]))ctx.fillRect(...pixel.args)}
export function renderCommands(ctx,commands,w,h,{correction=false,offset=0}={}){ctx.save();ctx.setTransform(1,0,0,1,offset,offset);ctx.clearRect(-offset,-offset,ctx.canvas.width,ctx.canvas.height);ctx.fillStyle='black';ctx.fillRect(0,0,w,h);ctx.strokeStyle=ctx.fillStyle;ctx.lineWidth=1;ctx.imageSmoothingEnabled=false;for(const {name,args:a} of commands){try{let [x,y,b,c,d,e]=a;if(name==='setColor'){const rgb=a.slice(0,3).map(n=>Math.max(0,Math.min(255,Number(n)||0))).map(n=>correction?Math.round(255*Math.pow(n/255,.82)):n);ctx.fillStyle=ctx.strokeStyle=`rgba(${rgb.join(',')},${(a[3]??255)/255})`;}else if(name==='drawClear'){ctx.fillRect(0,0,w,h)}else if(name==='drawText'){drawPixelText(ctx,x,y,b)}else if(name==='drawTextBox'){let str=String(d),lines=[],current='';for(const ch of str){if(ch==='\n'){lines.push(current);current=''}else{if(textWidth(current+ch)>b&&current){lines.push(current);current=''}current+=ch}}lines.push(current);let yy=y+((a[6]??-1)+1)/2*Math.max(0,c-lines.length*6);for(const line of lines){drawPixelText(ctx,x+((e??-1)+1)/2*Math.max(0,b-textWidth(line)),yy,line);yy+=6}}else if(name==='drawRectF'){ctx.fillRect(Math.round(x),Math.round(y),Math.round(b),Math.round(c))}else if(name==='drawRect'){x=Math.round(x);y=Math.round(y);b=Math.round(b);c=Math.round(c);ctx.fillRect(x,y,b+1,1);ctx.fillRect(x,y+c,b+1,1);ctx.fillRect(x,y,1,c+1);ctx.fillRect(x+b,y,1,c+1)}else if(name==='drawLine'){for(const pixel of linePixels(x,y,b,c))ctx.fillRect(...pixel.args)}else if(name.startsWith('drawCircle')){pixelCircle(ctx,x,y,b,name.endsWith('F'))}else if(name.startsWith('drawTriangle')){pixelTriangle(ctx,a,name.endsWith('F'))}else if(name==='drawMap'){ctx.save();ctx.fillStyle='#182928';ctx.fillRect(0,0,w,h);ctx.strokeStyle='#3b5650';for(let i=0;i<w;i+=16){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i,h);ctx.stroke()}for(let i=0;i<h;i+=16){ctx.beginPath();ctx.moveTo(0,i);ctx.lineTo(w,i);ctx.stroke()}ctx.restore()} }catch{} }ctx.restore()}
export function arcPoints(l){const cx=l.cx??l.w/2,cy=l.cy??l.h/2,n=Math.min(128,Math.max(8,Math.ceil((Math.hypot(cx,cy)+Math.hypot(l.w-cx,l.h-cy))*1.5)));return Array.from({length:n+1},(_,i)=>{let t=i/n,u=1-t;return [Math.round(l.x+2*u*t*cx+t*t*l.w),Math.round(l.y+2*u*t*cy+t*t*l.h)]})}
function arcPixels(l){
 const path=arcPoints(l),seen=new Set(),pixels=[];
 for(let i=1;i<path.length;i++){
  let [x,y]=path[i-1],[tx,ty]=path[i],dx=Math.abs(tx-x),sx=x<tx?1:-1,dy=-Math.abs(ty-y),sy=y<ty?1:-1,err=dx+dy;
  while(true){const key=x+','+y;if(!seen.has(key)){seen.add(key);pixels.push([x,y])}if(x===tx&&y===ty)break;const e=2*err;if(e>=dy){err+=dy;x+=sx}if(e<=dx){err+=dx;y+=sy}}
 }
 if(path.length===1)pixels.push(path[0]);
 return pixels;
}
function scaledTextCommands(l){
 const scale=Math.max(1,Math.min(8,Math.round(Number(l.textSize)||1))),source=String(l.text||'TEXT').toUpperCase(),lines=[];let current='',width=0;
 for(const ch of source){if(ch==='\n'){lines.push(current);current='';width=0;continue}const glyph=glyphs[ch]||glyphs['?'],advance=Math.max(4,glyph[0].length+1);if(l.box&&current&&width+advance>l.w/scale){lines.push(current);current='';width=0}current+=ch;width+=advance}lines.push(current);
 const rows=new Map();let yy=Math.round(l.y);
 for(const line of lines){let xx=Math.round(l.x);for(const ch of line){const glyph=glyphs[ch]||glyphs['?'];for(let gy=0;gy<5;gy++){const row=yy+gy*scale,intervals=rows.get(row)||[];for(let gx=0;gx<glyph[gy].length;){if(glyph[gy][gx]!=='1'){gx++;continue}let start=gx;while(gx+1<glyph[gy].length&&glyph[gy][gx+1]==='1')gx++;intervals.push([xx+start*scale,xx+(gx+1)*scale]);gx++}rows.set(row,intervals)}xx+=Math.max(4,glyph[0].length+1)*scale}yy+=6*scale}
 const cmds=[];for(const [y,intervals] of rows){intervals.sort((a,b)=>a[0]-b[0]);let start=null,end=null;for(const [x,x2] of intervals){if(start===null){start=x;end=x2}else if(x<=end)end=Math.max(end,x2);else{cmds.push({name:'drawRectF',args:[start,y,end-start,scale]});start=x;end=x2}}if(start!==null)cmds.push({name:'drawRectF',args:[start,y,end-start,scale]})}return cmds
}
function linePixels(x0,y0,x1,y1){let x=Math.round(x0),y=Math.round(y0),tx=Math.round(x1),ty=Math.round(y1),dx=Math.abs(tx-x),sx=x<tx?1:-1,dy=-Math.abs(ty-y),sy=y<ty?1:-1,err=dx+dy,rows=new Map();while(true){let xs=rows.get(y)||[];xs.push(x);rows.set(y,xs);if(x===tx&&y===ty)break;let e=2*err;if(e>=dy){err+=dy;x+=sx}if(e<=dx){err+=dx;y+=sy}}let out=[];for(const [yy,xs] of rows){xs.sort((a,b)=>a-b);let a=xs[0],b=a;for(let i=1;i<xs.length;i++){if(xs[i]<=b+1)b=xs[i];else{out.push({name:'drawRectF',args:[a,yy,b-a+1,1]});a=b=xs[i]}}out.push({name:'drawRectF',args:[a,yy,b-a+1,1]})}return out}
function tapeCommands(l,numbers){const out=[],step=Math.max(.01,Number(l.step)||10),spacing=Math.max(4,Number(l.spacing)||20),scale=Math.max(1,Math.min(8,Math.round(l.textSize||1))),vertical=l.direction==='vertical',value=Number(numbers[(l.channel||5)-1])||0,length=vertical?l.h:l.w,count=Math.min(128,Math.ceil(length/spacing/2)+2),base=Math.floor(value/step),wrap=Math.max(0,Number(l.wrap)||0);const clip=cmd=>{let [x,y,w,h]=cmd.args,x2=Math.min(l.x+l.w,x+w),y2=Math.min(l.y+l.h,y+h);x=Math.max(l.x,x);y=Math.max(l.y,y);if(x2>x&&y2>y)out.push({name:'drawRectF',args:[x,y,x2-x,y2-y]})};for(let i=base-count;i<=base+count;i++){const v=i*step,label=String(Math.round(wrap?((v%wrap)+wrap)%wrap:v)),offset=Math.round((v-value)/step*spacing),cx=l.x+l.w/2,cy=l.y+l.h/2,tx=vertical?l.x+3:Math.round(cx+offset-textWidth(label)*scale/2),ty=vertical?Math.round(cy-offset-2*scale):l.y+3;for(const cmd of scaledTextCommands({...l,x:tx,y:ty,text:label,textSize:scale,box:false}))clip(cmd);clip({args:vertical?[l.x,Math.round(cy-offset),2,1]:[Math.round(cx+offset),l.y+l.h-2,1,2]})}if(l.marker!==false)clip({args:vertical?[l.x+l.w-3,Math.floor(l.y+l.h/2)-1,3,2]:[Math.floor(l.x+l.w/2)-1,l.y+l.h-3,2,3]});return out}
function primitiveCommands(l,numbers=[],bools=[]){if(l.kind==='zone')return [];let a=[];const color=rgba(l.color);a.push({name:'setColor',args:color});if(l.kind==='tape'){a.push(...tapeCommands(l,numbers))}else if(l.kind==='arc'){for(const [x,y] of arcPixels(l))a.push({name:'drawRectF',args:[x,y,1,1]})}else if(l.kind==='brush'){const rows=new Map();for(const [px,py] of l.points||[]){if(!rows.has(py))rows.set(py,new Set());rows.get(py).add(px)}for(const [py,row] of [...rows].sort((a,b)=>a[0]-b[0])){const xs=[...row].sort((a,b)=>a-b);for(let i=0;i<xs.length;){let start=xs[i],end=start;while(i+1<xs.length&&xs[i+1]===end+1)end=xs[++i];a.push({name:'drawRectF',args:[l.x+start,l.y+py,end-start+1,1]});i++}}}else if(l.kind==='inputText'){let v=Number(numbers[(Number(l.channel)||1)-1])||0,dec=Math.max(0,Math.min(3,Number(l.decimals)||0));const text=String(l.prefix||'')+v.toFixed(dec)+String(l.suffix||'');if((l.textSize||1)>1)a.push(...scaledTextCommands({...l,text,box:false}));else a.push({name:'drawText',args:[l.x,l.y,text]})}else if(l.kind==='gauge'){let v=Number(numbers[(Number(l.channel)||1)-1])||0,min=Number(l.min)||0,max=Number.isFinite(Number(l.max))?Number(l.max):100,pct=Math.max(0,Math.min(1,(v-min)/(max-min||1)));a.push({name:'setColor',args:rgba(l.trackColor||'#31483c')},{name:'drawRectF',args:[l.x,l.y,l.w,l.h]},{name:'setColor',args:color},{name:'drawRectF',args:[l.x,l.y,Math.round(l.w*pct),l.h]})}else if(['button','zone'].includes(l.kind)){const down=!!bools[(Number(l.outputChannel)||1)-1];a.push({name:'setColor',args:rgba(down?(l.pressedColor||'#8fa47b'):(l.color||'#52624e'))},{name:l.fill?'drawRectF':'drawRect',args:[l.x,l.y,l.fill?l.w:Math.max(0,l.w-1),l.fill?l.h:Math.max(0,l.h-1)]},{name:'setColor',args:rgba(l.textColor||'#ffffff')},{name:'drawText',args:[l.x+2,l.y+Math.max(1,Math.floor((l.h-5)/2)),l.text||'BUTTON']})}else if(l.kind==='text'){if((Number(l.textSize)||1)>1)a.push(...scaledTextCommands(l));else a.push(l.box?{name:'drawTextBox',args:[l.x,l.y,l.w,l.h,l.text||'TEXT',-1,-1]}:{name:'drawText',args:[l.x,l.y,l.text||'TEXT']})}else if(l.kind==='line'){a.push(...linePixels(l.x,l.y,l.x+l.w,l.y+l.h))}else if(l.kind==='circle'){a.push({name:l.fill?'drawCircleF':'drawCircle',args:[l.x+l.w/2-.5,l.y+l.h/2-.5,Math.min(l.w,l.h)/2]})}else if(l.kind==='triangle'){a.push({name:l.fill?'drawTriangleF':'drawTriangle',args:[l.x+(l.w-1)/2,l.flipY?l.y+l.h-1:l.y,l.flipX?l.x:l.x+l.w-1,l.flipY?l.y:l.y+l.h-1,l.flipX?l.x+l.w-1:l.x,l.flipY?l.y:l.y+l.h-1]})}else{a.push({name:l.fill?'drawRectF':'drawRect',args:[l.x,l.y,l.fill?l.w:Math.max(0,l.w-1),l.fill?l.h:Math.max(0,l.h-1)]})}return a}
// Borders use the same Stormworks primitives in preview and exported Lua.
export function layerCommands(l,numbers=[],bools=[]){
 const base=primitiveCommands(l,numbers,bools),n=l.border&&!['inputText','gauge','tape','button','zone'].includes(l.kind)?Math.max(1,Math.min(4,Math.round(Number(l.borderWidth)||1))):0;
 if(!n)return base;
 const edge=[{name:'setColor',args:rgba(l.borderColor||'#000000')}];
 if(l.kind==='rect'&&l.fill)edge.push({name:'drawRectF',args:[l.x-n,l.y-n,l.w+2*n,l.h+2*n]});
 else if(l.kind==='circle'&&l.fill)edge.push({name:'drawCircleF',args:[l.x+l.w/2-.5,l.y+l.h/2-.5,Math.min(l.w,l.h)/2+n]});
 else for(let dy=-n;dy<=n;dy++)for(let dx=-n;dx<=n;dx++){
  for(const cmd of base.slice(1)){
   const args=[...cmd.args];args[0]+=dx;args[1]+=dy;
   if(cmd.name==='drawLine'||cmd.name.startsWith('drawTriangle')){args[2]+=dx;args[3]+=dy}
   if(cmd.name.startsWith('drawTriangle')){args[4]+=dx;args[5]+=dy}
   edge.push({name:cmd.name,args});
  }
 }
 return [...edge,...base];
}
export function compactCommands(commands){
 const out=[];let color='';
 for(const cmd of commands){
  const next={name:cmd.name,args:[...cmd.args]};
  if(next.name==='setColor'){
   if(next.args[3]===255)next.args.pop();const key=next.args.join(',');if(key===color)continue;color=key;
  }
  const prev=out.at(-1);
  if(next.name==='drawRectF'&&prev?.name==='drawRectF'&&next.args[0]===prev.args[0]&&next.args[2]===prev.args[2]&&next.args[1]===prev.args[1]+prev.args[3])prev.args[3]+=next.args[3];
  else out.push(next);
 }
 return out;
}
function optimizeLua(code){
 const plain=luamin.minify(code);
 // Dense pixel runs are cheaper as paired coordinates and a single drawing loop.
 const packed=code.replace(/((?:s\d+\(-?\d+,-?\d+,1,1\)\n){16,})/g,run=>{
  const calls=[...run.matchAll(/(s\d+)\((-?\d+),(-?\d+),1,1\)/g)];if(!calls.every(c=>c[1]===calls[0][1]))return run;
  return 'do local pixels={'+calls.flatMap(c=>[c[2],c[3]]).join(',')+'} for i=1,#pixels,2 do '+calls[0][1]+'(pixels[i],pixels[i+1],1,1) end end\n';
 });
 if(packed===code)return plain;
 const result=luamin.minify(packed);return result.length<plain.length?result:plain;
}
// Keep runtime output in precisely the same layer order as the drawing canvas.
const generatedCache=new Map();
export function generateLua(project,options={}){
 const key=JSON.stringify([project.background,project.layers,project.pages,project.currentPageId,options]);
 if(generatedCache.has(key))return generatedCache.get(key);
 const code=compileLua(project,options);if(generatedCache.size>=8)generatedCache.delete(generatedCache.keys().next().value);generatedCache.set(key,code);return code;
}
function compileLua(project,options={}){
 const pages=project.pages?.length?project.pages.map(pg=>({...pg,layers:pg.id===project.currentPageId?project.layers:pg.layers||[]})):[{id:'screen',layers:project.layers||[],links:[]}];
 const visible=pages.map((pg,pi)=>(options.renderPage!=null&&options.renderPage!==pi?[]:pg.layers).filter(l=>!l.hidden&&l.visible!==false));
 const all=visible.flat(), values=options.routerOnly?[]:all.filter(l=>['inputText','gauge','tape'].includes(l.kind)),buttons=all.filter(l=>['button','zone'].includes(l.kind));
 const numberChannel=l=>Math.max(1,Math.min(32,Math.round(Number(l.channel)||5)));
 const outputChannel=l=>Math.max(1,Math.min(32,Math.round(Number(l.outputChannel)||1)));
 const reads=new Map([...new Set(values.map(numberChannel))].map((ch,i)=>[ch,'v'+i]));
 const buttonVars=new Map(buttons.map((l,i)=>[l,'b'+i]));
 const boolChannels=options.externalPageChannel?[]:[...new Set(pages.flatMap(pg=>(pg.links||[]).filter(l=>l.inputChannel).map(l=>Math.max(1,Math.min(32,Math.round(l.inputChannel))))))];
 const q=value=>'"'+String(value??'').replace(/[\\"\x00-\x1f]/g,ch=>ch==='"'?'\\"':ch==='\\'?'\\\\':'\\'+ch.charCodeAt(0).toString().padStart(3,'0'))+'"';
 const n=value=>Number.isFinite(Number(value))?Math.round(Number(value)*100)/100:0;
 const rgb=value=>rgba(value).slice(0,3).join(',');
 const commands=visible.flatMap(ls=>ls.filter(l=>!['inputText','gauge','tape','button','zone'].includes(l.kind)).flatMap(layer=>layerCommands(layer)));
 const names=[...new Set(['setColor','drawClear',...commands.map(c=>c.name),...(values.some(l=>l.kind==='inputText')||buttons.some(l=>l.kind==='button')?['drawText']:[]),...(values.some(l=>l.kind==='gauge'||l.kind==='tape'||l.kind==='inputText'&&(l.textSize||1)>1)||buttons.some(l=>l.kind==='button'&&l.fill)?['drawRectF']:[]),...(buttons.some(l=>l.kind==='button'&&!l.fill)?['drawRect']:[])])];
 const aliases=Object.fromEntries(names.map((name,i)=>[name,'s'+i]));
 const sc=aliases.setColor,dt=aliases.drawText,rf=aliases.drawRectF;
 const needsPage=pages.length>1||!!options.externalPageChannel||!!options.routerOnly,needsEdge=needsPage&&!options.externalPageChannel&&pages.some(pg=>(pg.links||[]).some(link=>link.buttonId!=null&&pages.some(p=>p.id===link.target))),manyButtons=buttons.length>1;
 const lines=needsPage?['local page=1']:[];
 if(reads.size)lines.push('local '+[...reads.values()].join(',')+'='+[...reads].map(()=>0).join(','));
 if(buttons.length)lines.push('local '+[...buttonVars.values()].join(',')+'='+buttons.map(()=>false).join(','));
 if(needsEdge)lines.push('local wasTouch=false');
 if(boolChannels.length)lines.push('local '+boolChannels.map(c=>'was'+c).join(',')+'='+boolChannels.map(()=>false).join(','));
 if(reads.size||buttons.length||boolChannels.length||options.externalPageChannel||options.routerOnly){
  lines.push('function onTick()');if(options.externalPageChannel)lines.push('page=input.getNumber('+options.externalPageChannel+')');if(needsPage&&(buttons.length||boolChannels.length))lines.push('local pageNow=page');
  if(reads.size+((buttons.length)?2:0)>=3)lines.push('local gn=input.getNumber');
  const gn=reads.size+((buttons.length)?2:0)>=3?'gn':'input.getNumber';
  for(const [ch,v] of reads)lines.push(v+'='+gn+'('+ch+')');
  if(buttons.length)lines.push('local touch=input.getBool(1)','local x,y='+gn+'(3),'+gn+'(4)');if(manyButtons)lines.push('local hit=false');
  // The topmost button receives a touch; OR buttons sharing the same output.
  pages.forEach((pg,pi)=>{
   for(const l of [...visible[pi]].reverse().filter(l=>['button','zone'].includes(l.kind))){
    const v=buttonVars.get(l),x=Math.round(l.x),y=Math.round(l.y),w=Math.max(1,Math.round(l.w)),h=Math.max(1,Math.round(l.h));
    lines.push(v+'='+(manyButtons?'not hit and ':'')+(needsPage?'pageNow=='+(pi+1)+' and ':'')+'touch and x>='+x+' and x<'+(x+w)+' and y>='+y+' and y<'+(y+h));if(manyButtons)lines.push('if '+v+' then hit=true end');
    const link=(pg.links||[]).find(link=>String(link.buttonId)===String(l.id)),target=link?pages.findIndex(pg=>pg.id===link.target)+1:0;
    if(target&&!options.externalPageChannel&&needsPage)lines.push('if '+v+' and not wasTouch then page='+target+' end');
   }
  });
  if(options.outputs!==false)for(const ch of new Set(buttons.map(outputChannel)))lines.push('output.setBool('+ch+','+buttons.filter(l=>outputChannel(l)===ch).map(l=>buttonVars.get(l)).join(' or ')+')');
  for(const ch of boolChannels)lines.push('local now'+ch+'=input.getBool('+ch+')');
  pages.forEach((pg,pi)=>{for(const link of pg.links||[]){const target=pages.findIndex(pg=>pg.id===link.target)+1,ch=link.inputChannel;if(ch&&target&&!options.externalPageChannel&&needsPage)lines.push('if page==pageNow and pageNow=='+(pi+1)+' and now'+ch+' and not was'+ch+' then page='+target+' end')}});
  for(const ch of boolChannels)lines.push('was'+ch+'=now'+ch);
  if(needsEdge)lines.push('wasTouch=touch');
  if(options.routerOnly)lines.push('output.setNumber('+options.pageChannel+',page)');
  lines.push('end');
 }
 if(options.routerOnly)return luamin.minify(lines.join('\n'));
 const largeReadouts=values.filter(l=>l.kind==='tape'||l.kind==='inputText'&&(l.textSize||1)>1);
 if(largeReadouts.length){const chars=new Set(('0123456789.-? '+largeReadouts.map(l=>(l.prefix||'')+(l.suffix||'')).join('')).toUpperCase());lines.push('local font={'+[...chars].map(ch=>{const g=glyphs[ch]||glyphs['?'];return '['+q(ch)+']={'+g[0].length+','+g.map(row=>parseInt(row,2)).join(',')+'}'}).join(',')+'}');lines.push('local function bigText(x,y,t,z,a,b,w,h) for ch in string.upper(t):gmatch(".") do local g=font[ch] or font["?"] for j=1,5 do for k=0,g[1]-1 do if math.floor(g[j+1]/2^(g[1]-1-k))%2==1 then local px,py=x+k*z,y+(j-1)*z local ex,ey=px+z,py+z if a then px=math.max(px,a) py=math.max(py,b) ex=math.min(ex,a+w) ey=math.min(ey,b+h) end if ex>px and ey>py then screen.drawRectF(px,py,ex-px,ey-py) end end end end x=x+math.max(4,g[1]+1)*z end end')}
 lines.push('function onDraw()','local '+names.map(name=>aliases[name]).join(',')+'='+names.map(name=>'screen.'+name).join(','));
 pages.forEach((pg,pi)=>{
  if(options.renderPage!=null&&pi!==options.renderPage)return;
  if(needsPage)lines.push('if page=='+(pi+1)+' then');lines.push(sc+'('+rgb(pg.background||project.background)+')',aliases.drawClear+'()');
  let staticCommands=[];const flush=()=>{if(!staticCommands.length)return;let optimized=compactCommands(staticCommands);for(const command of optimized)lines.push(aliases[command.name]+'('+command.args.map(v=>typeof v==='string'?q(v):n(v)).join(',')+')');staticCommands=[]};
  for(const l of visible[pi]){
   if(l.kind==='zone')continue;
   if(['inputText','gauge','tape','button'].includes(l.kind))flush();
   const x=Math.round(l.x),y=Math.round(l.y),w=Math.max(1,Math.round(l.w)),h=Math.max(1,Math.round(l.h));
   if(l.kind==='inputText'){
    const decimals=Math.max(0,Math.min(3,Math.round(Number(l.decimals)||0)));
    lines.push(sc+'('+rgb(l.color)+')',((l.textSize||1)>1?'bigText':dt)+'('+x+','+y+','+(l.prefix?q(l.prefix)+'..':'')+'string.format("%.'+decimals+'f",'+reads.get(numberChannel(l))+')'+(l.suffix?'..'+q(l.suffix):'')+((l.textSize||1)>1?','+Math.max(1,Math.min(8,Math.round(l.textSize))):'')+')');
   }else if(l.kind==='tape'){
    const step=Math.max(.01,Number(l.step)||10),spacing=Math.max(4,Number(l.spacing)||20),z=Math.max(1,Math.min(8,Math.round(l.textSize||1))),vertical=l.direction==='vertical',count=Math.min(128,Math.ceil((vertical?h:w)/spacing/2)+2),v=reads.get(numberChannel(l)),wrap=Math.max(0,Number(l.wrap)||0);
    lines.push(sc+'('+rgb(l.color)+')','for i=math.floor('+v+'/'+step+')-'+count+',math.floor('+v+'/'+step+')+'+count+' do local offset=math.floor((i*'+step+'-'+v+')/'+step+'*'+spacing+'+.5) local t=tostring(math.floor('+(wrap?'(i*'+step+'%'+wrap+')':'i*'+step)+'+.5))');
    lines.push('bigText('+(vertical?x+3:x+w/2+'+offset-#t*'+(4*z/2))+','+(vertical?y+h/2+'-offset-'+2*z:y+3)+',t,'+z+','+[x,y,w,h].join(',')+')');
    lines.push('local tick='+(vertical?y+h/2+'-offset':x+w/2+'+offset')+' if tick>='+ (vertical?y:x)+' and tick<'+(vertical?y+h:x+w)+' then '+rf+'('+(vertical?[x,'tick',2,1]:['tick',y+h-2,1,2]).join(',')+') end end');
    if(l.marker!==false)lines.push(rf+'('+(vertical?[x+w-3,Math.floor(y+h/2)-1,3,2]:[Math.floor(x+w/2)-1,y+h-3,2,3]).join(',')+')');
   }else if(l.kind==='gauge'){
    const min=Number(l.min)||0,max=Number.isFinite(Number(l.max))?Number(l.max):100;
    lines.push(sc+'('+rgb(l.trackColor||'#31483c')+')',rf+'('+[x,y,w,h].join(',')+')',sc+'('+rgb(l.color)+')',rf+'('+x+','+y+',math.floor(math.max(0,math.min(1,('+reads.get(numberChannel(l))+'-('+min+'))/'+(max-min||1)+'))*'+w+'+0.5),'+h+')');
   }else if(['button','zone'].includes(l.kind)){
    lines.push('if '+buttonVars.get(l)+' then '+sc+'('+rgb(l.pressedColor||'#8fa47b')+') else '+sc+'('+rgb(l.color||'#52624e')+') end',aliases[l.fill?'drawRectF':'drawRect']+'('+[x,y,l.fill?w:Math.max(0,w-1),l.fill?h:Math.max(0,h-1)].join(',')+')',sc+'('+rgb(l.textColor||'#ffffff')+')',dt+'('+(x+2)+','+(y+Math.max(1,Math.floor((h-5)/2)))+','+q(l.text||'BUTTON')+')');
   }else staticCommands.push(...layerCommands(l));
  }
  flush();if(needsPage)lines.push('end');
 });
 lines.push('end');return optimizeLua(lines.join('\n'));
}
export function defaultProject(){return {version:2,pixelGeometry:1,name:'Engine display',width:96,height:64,monitor:'3x2',rotated:false,bezel:'grey',background:'#000000',layers:[{id:1,name:'Header',kind:'rect',x:0,y:0,w:96,h:13,color:'#acc2b3',fill:true},{id:2,name:'Title',kind:'text',x:6,y:4,w:60,h:5,text:'ENGINE STATUS',color:'#172522'},{id:3,name:'RPM input',kind:'inputText',x:6,y:22,w:75,h:7,prefix:'RPS  ',suffix:'',channel:5,decimals:1,color:'#c6d8cc'},{id:4,name:'Temperature input',kind:'inputText',x:6,y:33,w:76,h:7,prefix:'TEMP  ',suffix:' C',channel:6,decimals:0,color:'#c6d8cc'},{id:5,name:'Gauge track',kind:'rect',x:6,y:47,w:62,h:7,color:'#31483c',fill:true},{id:6,name:'Fuel gauge',kind:'gauge',x:6,y:47,w:62,h:7,min:0,max:100,channel:7,trackColor:'#31483c',color:'#b5c8a0',fill:true},{id:7,name:'Fuel input',kind:'inputText',x:73,y:48,w:20,h:7,prefix:'',suffix:'%',channel:7,decimals:0,color:'#c6d8cc'}],code:'',library:'-- Your reusable Lua helpers go here.\n',properties:[],numbers:[96,64,0,0,12,82,72,...Array(25).fill(0)],bools:Array(32).fill(false),inputMap:{number:Array.from({length:32},(_,i)=>['Touch screen width','Touch screen height','Touch X','Touch Y','Engine RPS','Coolant temperature','Fuel level'][i]||'Number input '+(i+1)),bool:Array.from({length:32},(_,i)=>i===0?'Touch pressed':'Boolean input '+(i+1))},settings:{tps:60,fps:60,delay:0,touch:false,correction:false,overflow:false},mode:'draw'}}

export function weaponsSelectorProject(){
 const ink='#d5e5dc',muted='#78958a',mint='#75efb0',amber='#ffc968',panel='#102326',line='#31504b';
 const layers=[
  {id:100,name:'Top bar',kind:'rect',x:0,y:0,w:96,h:11,color:'#153238',fill:true},
  {id:101,name:'Title',kind:'text',x:3,y:3,w:67,h:5,text:'WEAPONS / STORES',color:ink},
  {id:102,name:'Mode',kind:'text',x:74,y:3,w:19,h:5,text:'SAFE',color:amber},
  {id:103,name:'Aircraft centerline',kind:'line',x:48,y:14,w:0,h:31,color:muted},
  {id:104,name:'Left wing upper',kind:'line',x:48,y:21,w:-21,h:12,color:mint},
  {id:105,name:'Right wing upper',kind:'line',x:48,y:21,w:21,h:12,color:mint},
  {id:106,name:'Left wing lower',kind:'line',x:27,y:33,w:7,h:7,color:mint},
  {id:107,name:'Right wing lower',kind:'line',x:69,y:33,w:-7,h:7,color:mint},
  {id:108,name:'Tail left',kind:'line',x:43,y:38,w:-8,h:7,color:muted},
  {id:109,name:'Tail right',kind:'line',x:53,y:38,w:8,h:7,color:muted},
  {id:110,name:'Nose',kind:'triangle',x:45,y:13,w:6,h:10,color:mint,fill:true},
  {id:111,name:'Station 1 marker',kind:'circle',x:31,y:31,w:4,h:4,color:amber,fill:true},
  {id:112,name:'Station 2 marker',kind:'circle',x:61,y:31,w:4,h:4,color:amber,fill:true},
  {id:113,name:'Station 3 marker',kind:'circle',x:36,y:40,w:4,h:4,color:mint,fill:true},
  {id:114,name:'Station 4 marker',kind:'circle',x:56,y:40,w:4,h:4,color:mint,fill:true},
  {id:115,name:'Selector divider',kind:'line',x:2,y:48,w:92,h:0,color:line},
  {id:116,name:'Left card 1',kind:'rect',x:2,y:51,w:45,h:19,color:panel,border:true,borderWidth:1,borderColor:line,fill:true},
  {id:117,name:'Right card 1',kind:'rect',x:49,y:51,w:45,h:19,color:panel,border:true,borderWidth:1,borderColor:line,fill:true},
  {id:118,name:'Left card 2',kind:'rect',x:2,y:73,w:45,h:19,color:panel,border:true,borderWidth:1,borderColor:line,fill:true},
  {id:119,name:'Right card 2',kind:'rect',x:49,y:73,w:45,h:19,color:panel,border:true,borderWidth:1,borderColor:line,fill:true},
  {id:120,name:'Select AIM-9',kind:'button',x:4,y:53,w:41,h:8,color:'#20433b',pressedColor:'#347859',textColor:ink,text:'1 AIM-9',fill:true,outputChannel:1},
  {id:121,name:'Select AMRAAM left',kind:'button',x:51,y:53,w:41,h:8,color:'#20433b',pressedColor:'#347859',textColor:ink,text:'2 AMRAAM',fill:true,outputChannel:2},
  {id:122,name:'Select AMRAAM right',kind:'button',x:4,y:75,w:41,h:8,color:'#20433b',pressedColor:'#347859',textColor:ink,text:'3 AMRAAM',fill:true,outputChannel:3},
  {id:123,name:'Select JDAM',kind:'button',x:51,y:75,w:41,h:8,color:'#20433b',pressedColor:'#347859',textColor:ink,text:'4 JDAM',fill:true,outputChannel:4},
  {id:124,name:'AIM-9 quantity',kind:'inputText',x:5,y:63,w:38,h:5,prefix:'QTY ',channel:5,decimals:0,color:mint},
  {id:125,name:'AMRAAM quantity left',kind:'inputText',x:52,y:63,w:38,h:5,prefix:'QTY ',channel:6,decimals:0,color:mint},
  {id:126,name:'AMRAAM quantity right',kind:'inputText',x:5,y:85,w:38,h:5,prefix:'QTY ',channel:7,decimals:0,color:mint},
  {id:127,name:'JDAM quantity',kind:'inputText',x:52,y:85,w:38,h:5,prefix:'QTY ',channel:8,decimals:0,color:mint}
 ];
 const numberNames=['Touch screen width','Touch screen height','Touch X','Touch Y','AIM-9 count','AMRAAM left count','AMRAAM right count','JDAM count'];
 return {...defaultProject(),name:'Weapons / hardpoint selector',width:96,height:96,monitor:'3x3',bezel:'graphite',background:'#000000',layers,numbers:[96,96,0,0,2,4,4,2,...Array(24).fill(0)],bools:Array(32).fill(false),inputMap:{number:Array.from({length:32},(_,i)=>numberNames[i]||'Number input '+(i+1)),bool:Array.from({length:32},(_,i)=>i===0?'Touch pressed':'Boolean input '+(i+1))},settings:{tps:60,fps:60,delay:0,touch:true,correction:false,overflow:false},mode:'draw'};
}
