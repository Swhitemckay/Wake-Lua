import {readFileSync,readdirSync,mkdirSync,writeFileSync,lstatSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {zipSync,unzipSync} from 'fflate';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const version=JSON.parse(readFileSync(path.join(root,'package.json'),'utf8')).version;
const prefix=`wake-lua-${version}`;
const output=path.join(root,'release');mkdirSync(output,{recursive:true});
const collect=paths=>{const files={};const add=name=>{const location=path.join(root,name);const entries=readdirSync(location,{withFileTypes:true});for(const entry of entries){if(entry.isSymbolicLink())throw Error('Archive refuses symbolic links');const next=name+'/'+entry.name;if(entry.isDirectory())add(next);else files[next]=readFileSync(path.join(root,next))}};for(const name of paths){if(lstatSync(path.join(root,name)).isFile())files[name]=readFileSync(path.join(root,name));else add(name)}return files};
const common=['README.md','BETA.md','LICENSE','dist','scripts/preview.mjs'];
const archives=[['source',collect([...common,'src','tests','.github','scripts/package-beta.mjs','package.json','pnpm-lock.yaml','pnpm-workspace.yaml','build.mjs','.gitignore'])],['prebuilt',collect(common)]];
const sums=[];
for(const [kind,files] of archives){const packed=Object.fromEntries(Object.entries(files).map(([name,bytes])=>[prefix+'/'+name,bytes]));const bytes=zipSync(packed,{level:9});const unpacked=unzipSync(bytes);for(const [name,original] of Object.entries(packed)){if(!Buffer.from(unpacked[name]).equals(original))throw Error('Archive verification failed: '+name)}const name=prefix+'-'+kind+'.zip';writeFileSync(path.join(output,name),bytes);sums.push(createHash('sha256').update(bytes).digest('hex')+'  '+name);console.log(`${name}: ${Object.keys(files).length} verified files`)}
writeFileSync(path.join(output,'SHA256SUMS.txt'),sums.join('\n')+'\n');
