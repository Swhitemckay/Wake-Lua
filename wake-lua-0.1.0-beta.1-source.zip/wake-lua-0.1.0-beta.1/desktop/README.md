# Wake Lua desktop beta

The app includes the workbench and Lua simulator locally. No website login or internet connection is needed. Projects are saved in the app's own local storage; use Projects → Import to bring in a browser project backup. Export opens a native Save dialog.

## Build and run

Install Node 22+ and pnpm, then run `pnpm install`.

- `pnpm desktop`: open the desktop app.
- `pnpm desktop:mac`: build DMG installers for Apple Silicon and Intel Macs (run on macOS).
- `pnpm desktop:windows`: build the Windows x64 installer (run on Windows).

Installers appear in `release/desktop`.

On GitHub, run Actions → Desktop beta installers → Run workflow. Download the Windows and Mac artifacts once the jobs finish. Artifacts follow the repository's access permissions; this workflow does not publish a release.

These initial beta builds are unsigned. Signing and macOS notarization require the owner's developer certificates and accounts. Operating systems may display an unidentified publisher warning. The local app itself does not enforce invitations; only distribute installers to approved testers.

The renderer has no Node access. The app serves only bundled assets using a secure local protocol and blocks external navigation. Existing project JSON and Lua import/export remain available.
